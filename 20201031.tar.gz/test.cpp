#include <iostream>
using namespace  std;
int main ()
{
    cout<<"123"<<endl;
    return 0;   

}
